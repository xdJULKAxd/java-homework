import org.codehaus.jackson.annotate.JsonProperty;

// model danych dla jsona
public class User {

    @JsonProperty("name")
    String name;

    @JsonProperty("age")
    String age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", age='" + age + '\'' +
                '}';
    }
}
