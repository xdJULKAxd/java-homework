import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.stream.Stream;

public class SplitFile {

    private static final String PATH2 = "src/main/resources/file2.txt";
    private static final String PATH = "src/main/resources/file.txt";

    public static void main(String[] args) {
        //readFileLineByLine();
        splitText();
    }

    // metoda dzieli linie po separatorze nowej linii
    private static void splitText(){
        try {
            BufferedReader br = new BufferedReader(new FileReader(PATH2)); // otwieramy plik do klasy bufferReader
            String line;
            int i = 1;
            while ((line = br.readLine()) != null) {
                String[] lines = line.split("\\\\r?\\\\n|\\\\r"); // tniemy pobrany string wedlug znaku nowej linii

                for (String s : lines){
                    System.out.println(i + ". "+s); // wiswietlamy tekst wraz z iteratorem
                    i++;
                }
                if (lines == null || lines.length == 0){
                    System.out.println(i + ". "+line);
                    i++;
                }
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // metoda czyta linia po linie
    private static void readFileLineByLine(){
        try {
            BufferedReader br = new BufferedReader(new FileReader(PATH)); // do uzycie w przypadku gdy nie mamy w pliku tekst podzielonego po znakach \n\r tylko uzyte sa entery
            String line;
            int i = 1;
            while ((line = br.readLine()) != null) { // czytamy po kolei linie
                System.out.println(i + ". "+line); // i wyswietlamy
                i++;
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
