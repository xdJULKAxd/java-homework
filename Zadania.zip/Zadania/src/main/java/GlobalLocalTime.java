import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class GlobalLocalTime {

    public static void main(String[] args) {

        String sZone = "Europe/Paris"; // wybieramy jedna ze stref z klasy Zone
        Instant nowUtc = Instant.now(); // pobieramy aktualny czas
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss"); // ustawiamy format czasu
        ZoneId zone = ZoneId.of(sZone);
        ZonedDateTime zonedDateTime = ZonedDateTime.ofInstant(nowUtc, zone); // ustawiamy czas wedlug strefy
        System.out.println("Local time " + sZone + " " + zonedDateTime.format(formatter)); // wyswietlamy na konsoli

        formatter = formatter.withZone(ZoneOffset.UTC); // ustawimy strefe na globalna
        System.out.println("Global time " + formatter.format(nowUtc));

    }
}
