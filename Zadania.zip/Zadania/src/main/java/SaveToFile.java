import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Scanner;

public class SaveToFile {

    private static final String PATH = "src/main/resources/file.txt";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Podaj tekst do zapisania w pliku: ");
        String next = scanner.next(); // pobieramy tesk z konsoli
        writeToFile(next);

    }

    private static void writeToFile(String text) {

        try {
            BufferedWriter writer = Files.newBufferedWriter(Paths.get(PATH), StandardOpenOption.APPEND); // otwieramy plik w ktorym mamy pisac
            writer.write(text); // wpisujmey tekst do pliku
            writer.newLine(); // oraz nowa linie
            writer.close(); // zamykamy plik
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
