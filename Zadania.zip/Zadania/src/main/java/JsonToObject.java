import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class JsonToObject {

    private final static String PATH = "src/main/resources/user.json";

    public static void main(String[] args) {
        ObjectMapper mapper = new ObjectMapper(); // tworzymy mapper jsona
        List<User> list = null; // tworzymy liste userow w ktorej beda trzymane dane z pliku json
        try {
            list = mapper.readValue((new File(PATH)), new TypeReference<List<User>>(){}); // czytamy plik json i mapujemy do obiektu
        } catch (IOException e) {
            e.printStackTrace();
        }

        for (User u : list){
            System.out.println(u); // wyseitlamy pobrana liste
        }
    }
}
